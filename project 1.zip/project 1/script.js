let tasks = [];

function renderTasks() {
  const taskList = document.getElementById('taskList');
  taskList.innerHTML = '';

  tasks.forEach((task, index) => {
    const taskItem = document.createElement('li');
    taskItem.className = 'taskItem';
    taskItem.innerHTML = `
      <span>${task.text} - ${task.date}</span>
      <button onclick="completeTask(${index})">Complete</button>
      <button onclick="deleteTask(${index})">Delete</button>
    `;
    taskList.appendChild(taskItem);
  });
}

function addTask() {
  const taskField = document.getElementById('taskField');
  const dateField = document.getElementById('dateField');

  const text = taskField.value.trim();
  const date = dateField.value.trim();

  if (text !== '' && date !== '') {
    const task = { text, date, completed: false };
    tasks.push(task);
    taskField.value = '';
    dateField.value = '';
    renderTasks();
  } else {
    alert('Please enter a task and date!');
  }
}

function completeTask(index) {
  tasks[index].completed = true;
  renderTasks();
}

function deleteTask(index) {
  tasks.splice(index, 1);
  renderTasks();
}

renderTasks();
